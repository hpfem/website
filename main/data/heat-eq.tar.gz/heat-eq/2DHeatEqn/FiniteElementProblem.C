#include "NOX_Common.H"
#include "Epetra_Comm.h"
#include "Epetra_Map.h"
#include "Epetra_Vector.h"
#include "Epetra_Import.h"
#include "Epetra_CrsGraph.h"
#include "Epetra_CrsMatrix.h"
#include "Basis.h"

#include "FiniteElementProblem.h"

// Constructor - creates the Epetra objects (maps and vectors) 
FiniteElementProblem::FiniteElementProblem(Epetra_Comm& comm, const std::string &filename) :
  Comm(&comm)
{

  // Commonly used variables
  int i;

#ifdef DEBUG
  in_mesh = new Mesh(0,true);
#else
  in_mesh = new Mesh(0,false);
#endif

  in_mesh->read_exodus(&filename[0]);
  in_mesh->compute_nodal_adj();

  NumEquationsPerNode = 1; //number of unknowns per node
  NumGlobalElements = in_mesh->get_num_elem();
  NumGlobalNodes = in_mesh->get_num_nodes();
  NumGlobalUnknowns = NumEquationsPerNode * NumGlobalNodes;

  // Construct a Source Map that puts approximately the same 
  // Number of unknowns on each processor in uniform global ordering

  StandardMap = new Epetra_Map(NumGlobalUnknowns, 0, *Comm);

  // Construct Linear Objects  

  initialSolution = Teuchos::rcp(new Epetra_Vector(*StandardMap));
//  AA = new Epetra_CrsGraph(Copy, *StandardMap, 5);
  AA = new Epetra_CrsGraph(Copy, *StandardMap, 0); // Dynamically allocate

  // Allocate the memory for a matrix dynamically (i.e. the graph is dynamic).
  generateGraph(*AA);

  // Create a second matrix using graph of first matrix - this creates a 
  // static graph so we can refill the new matirx after FillComplete()
  // is called.
  A = Teuchos::rcp(new Epetra_CrsMatrix (Copy, *AA));
  A->FillComplete();
}

// Destructor
FiniteElementProblem::~FiniteElementProblem()
{
  delete AA;
  delete StandardMap;
  delete in_mesh;
}

// Matrix and Residual Fills
bool FiniteElementProblem::evaluate(FillType f, 
				    const Epetra_Vector* soln, 
				    Epetra_Vector* tmp_rhs, 
				    Epetra_RowMatrix* tmp_matrix) {

  flag = f;

  // Set the incoming linear objects

  if (flag == F_ONLY) {

    rhs = tmp_rhs;

  } else if (flag == MATRIX_ONLY) {

    // RPP: A doesn't need to be set, we are implicitly filling tmp_matrix 
    // with a shared jacobian.
    //A = dynamic_cast<Epetra_CrsMatrix*> (tmp_matrix);

  } else if (flag == ALL) { 

    rhs = tmp_rhs;
    //A = dynamic_cast<Epetra_CrsMatrix*> (tmp_matrix);

  } else {

    cout << "ERROR: FiniteElementProblem::fillMatrix() - FillType flag is broken" << endl;
    throw;

  }

  // Create the overlapped solution and position vectors

//  Epetra_Vector u(*StandardMap);
  Epetra_Vector u(*soln);
  Epetra_Vector x(*StandardMap);

  // Export Solution to Overlap vector

//  u.Import(*soln, *Importer, Insert);

  // Declare required variables

  int i,j,k,ierr;
  int ne;

  int row, column;
  double jac;
  double *xx, *yy;
  double *uu;
  double kk;
  int nodeid, blk, n_nodes_per_elem;

  Basis *ubasis;

  // Zero out the objects that will be filled

  if ((flag == MATRIX_ONLY) || (flag == ALL)) i=A->PutScalar(0.0);
  if ((flag == F_ONLY)    || (flag == ALL)) i=rhs->PutScalar(0.0);

for(blk = 0; blk < in_mesh->get_num_elem_blks(); blk++){

n_nodes_per_elem = in_mesh->get_num_nodes_per_elem_in_blk(blk);

switch(n_nodes_per_elem){

	case 3 : // linear triangle
		ubasis = new BasisLTri;
		break;

	case 4 : // linear quad
		ubasis = new BasisLQuad;
		break;

}

  xx = new double[n_nodes_per_elem];
  yy = new double[n_nodes_per_elem];
  uu = new double[n_nodes_per_elem];

  // Loop Over # of Finite Elements on Processor

  for (ne=0; ne < in_mesh->get_num_elem_in_blk(blk); ne++) {

    for(k = 0; k < n_nodes_per_elem; k++){

       nodeid = in_mesh->get_node_id(blk, ne, k);

       xx[k] = in_mesh->get_x(nodeid);
       yy[k] = in_mesh->get_y(nodeid);
       uu[k] = u[nodeid];  // copy initial guess or old solution into local temp

    }
    
    // Loop Over Gauss Points
    for(int gp=0; gp < ubasis->ngp; gp++) { 

      // Calculate the basis function at the gauss point

      //ubasis->getBasis(gp, xx, yy);
      ubasis->getBasis(gp, xx, yy, uu);

      if ((flag == F_ONLY)    || (flag == ALL)) {
	            
        // Loop over Nodes in Element

        for (i=0; i< n_nodes_per_elem; i++) {

          row = nodeid = in_mesh->get_node_id(blk, ne, i);

	  double dphidx = 0;
	  double dphidy = 0;

           for(j = 0; j < n_nodes_per_elem; j++){

             kk = (ubasis->dxidx * ubasis->dxidx + ubasis->dxidy * ubasis->dxidy) *
                           ubasis->dphidxi[i] * ubasis->dphidxi[j] +
                   (ubasis->dxidx * ubasis->detadx + ubasis->dxidy * ubasis->detady) *
                          (ubasis->dphidxi[i] * ubasis->dphideta[j] + ubasis->dphideta[i] * ubasis->dphidxi[j]) +
                   (ubasis->detadx * ubasis->detadx + ubasis->detady * ubasis->detady) *
                          ubasis->dphideta[i] * ubasis->dphideta[j];	
 	         (*rhs)[nodeid]+= ubasis->jac * ubasis->wt * kk * uu[j];

 	      }

	}
      }
    } 
  }

  // Insert Boundary Conditions and modify Jacobian and function (F)
  // U(0)=1

    if ((flag == F_ONLY)    || (flag == ALL)) {

//      (*rhs)[0]= (*soln)[0] - BC value;

      //gh HACKALERT assume for now that the only node sets in the file are boundary nodes

      for ( j = 0; j < in_mesh->get_node_set(0).size(); j++ ){

        nodeid = in_mesh->get_node_set_entry(0, j);

        (*rhs)[nodeid] =
                (*soln)[nodeid] - 0.0; // Dirichlet BC of zero

      }
      for ( j = 0; j < in_mesh->get_node_set(1).size(); j++ ){

        nodeid = in_mesh->get_node_set_entry(1, j);

        (*rhs)[nodeid] =
                (*soln)[nodeid] - 1.0; // Dirichlet BC of one

      }
  }

  delete [] xx;
  delete [] yy;
  delete [] uu;

}

  A->FillComplete();

  delete ubasis;

  return true;

}

Teuchos::RCP<Epetra_Vector> FiniteElementProblem::getSolution()
{
  return initialSolution;
}
  
Teuchos::RCP<Epetra_CrsMatrix> FiniteElementProblem::getJacobian()
{
  return A;
}

Epetra_CrsGraph& FiniteElementProblem::generateGraph(Epetra_CrsGraph& AA)
{

  // Declare required variables

    int nn, neqn, j, tcol[3];

  // Loop Over # of Finite Elements on Processor; ie nodes

    for (nn = 0; nn < NumGlobalNodes; nn++) {

       std::vector<int> column (in_mesh->get_nodal_adj(nn));

       column.push_back(nn);//cn put the diagonal in

       // now have one equation per node

        for(neqn = 0; neqn < NumEquationsPerNode; neqn++){

           for(j = 0; j < column.size(); j++){

               tcol[0] = NumEquationsPerNode * column[j];
               //tcol[1] = tcol[0] + 1;
               //tcol[2] = tcol[0] + 2;
               AA.InsertGlobalIndices(NumEquationsPerNode * nn + neqn, NumEquationsPerNode, tcol);
          }
       }
    }

    AA.FillComplete();

//   AA.SortIndices();
//   AA.RemoveRedundantIndices();

#ifdef DEBUG
     cout << "Initial graph AA is :" << endl;
     AA.PrintGraphData(std::cout);
#endif

     return AA;

}

