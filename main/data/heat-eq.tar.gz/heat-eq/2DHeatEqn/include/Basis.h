// 1D Linear basis function for finite element method

#ifndef _NOX_EXAMPLE_EPETRA_LINEAR_BASIS_H
#define _NOX_EXAMPLE_EPETRA_LINEAR_BASIS_H

class Basis {

 public:

  // Constructor
  Basis(){}

  // Destructor
  virtual ~Basis(){}

  // Calculates the values of u and x at the specified gauss point
  virtual void getBasis(int gp, double *x, double *y) = 0;
  virtual void getBasis(int gp, double *x, double *y, double *u) = 0;

 public:
  // Variables that are calculated at the gauss point
  int ngp;
  double *phi, *dphidxi, *dphideta, *abscissa, *weight; 
  double xi, eta, wt, jac;
  double dxidx, dxidy, detadx, detady;
  double uu, xx, yy, dudx, dudy;
};

class BasisLTri : public Basis {

 public:

  // Constructor
  BasisLTri();

  // Destructor
  virtual ~BasisLTri();

  // Calculates the values of u and x at the specified gauss point
  virtual void getBasis(int gp, double *x, double *y);
  void getBasis(int gp, double *x, double *y, double *u);

 public:
  // Variables that are calculated at the gauss point
};

class BasisLQuad : public Basis {

 public:

  // Constructor
  BasisLQuad();

  // Destructor
  virtual ~BasisLQuad();

  // Calculates the values of u and x at the specified gauss point
  virtual void getBasis(int gp, double *x, double *y);
  void getBasis(int gp, double *x, double *y, double *u);

 public:
  // Variables that are calculated at the gauss point
};

class BasisQTri : public Basis {

 public:

  // Constructor
  BasisQTri();

  // Destructor
  virtual ~BasisQTri();

  // Calculates the values of u and x at the specified gauss point
  virtual void getBasis(int gp, double *x, double *y, double *u);
  virtual void getBasis(int gp, double *x, double *y);

 public:

};

#endif
