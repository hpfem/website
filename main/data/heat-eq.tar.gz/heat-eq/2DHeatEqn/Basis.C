#include "NOX_Common.H"
#include "Basis.h"

template <typename T, size_t size>
void setN(int N, T (&abscissa)[size], T (&weight)[size]){

 if ( N == 2 ) {
    abscissa[0] = -1.0L/sqrt(3.0L);
    abscissa[1] =  1.0L/sqrt(3.0L);
    weight[0] = 1.0;
    weight[1] = 1.0;
  } else if ( N == 3 ) {
    abscissa[0] = -sqrt(15.0L)/5.0L;
    abscissa[1] =  0.0;
    abscissa[2] =  sqrt(15.0L)/5.0L;
    weight[0] = 5.0L/9.0L;
    weight[1] = 8.0L/9.0L;
    weight[2] = 5.0L/9.0L;
  } else if ( N == 4 ) {
    abscissa[0] =  -sqrt(525.0L+70.0L*sqrt(30.0L))/35.0L;
    abscissa[1] =  -sqrt(525.0L-70.0L*sqrt(30.0L))/35.0L;
    abscissa[2] =   sqrt(525.0L-70.0L*sqrt(30.0L))/35.0L;
    abscissa[3] =   sqrt(525.0L+70.0L*sqrt(30.0L))/35.0L;
    weight[0] = (18.0L-sqrt(30.0L))/36.0L;
    weight[1] = (18.0L+sqrt(30.0L))/36.0L;
    weight[2] = (18.0L+sqrt(30.0L))/36.0L;
    weight[3] = (18.0L-sqrt(30.0L))/36.0L;
  } else if ( N == 5 ) {
    abscissa[0] = -sqrt(245.0L+14.0L*sqrt(70.0L))/21.0L;
    abscissa[1] = -sqrt(245.0L-14.0L*sqrt(70.0L))/21.0L;
    abscissa[2] = 0.0;
    abscissa[3] = sqrt(245.0L-14.0L*sqrt(70.0L))/21.0L;
    abscissa[4] = sqrt(245.0L+14.0L*sqrt(70.0L))/21.0L;
    weight[0] = (322.0L-13.0L*sqrt(70.0L))/900.0L;
    weight[1] = (322.0L+13.0L*sqrt(70.0L))/900.0L;
    weight[2] = 128.0L/225.0L;
    weight[3] = (322.0L+13.0L*sqrt(70.0L))/900.0L;
    weight[4] = (322.0L-13.0L*sqrt(70.0L))/900.0L;
  } else {
    std::cout<<"WARNING: only 1 < N < 6 gauss points supported at this time, defaulting to N = 2"<<std::endl;
    abscissa[0] = -1.0L/sqrt(3.0L);
    abscissa[1] =  1.0L/sqrt(3.0L);
    weight[0] = 1.0;
    weight[1] = 1.0;
  }
}

// Constructor
BasisLTri::BasisLTri() {
  phi = new double[3];
  dphidxi = new double[3];
  dphideta = new double[3];
  ngp = 1;  // number of Gauss points
}

// Destructor
BasisLTri::~BasisLTri() {
  delete [] phi;
  delete [] dphidxi;
  delete [] dphideta;
}

void BasisLTri::getBasis(int gp, double *x, double *y){
  getBasis(gp, x, y, NULL);
}

// Calculates a linear 1D tri basis
void BasisLTri::getBasis(int gp, double *x, double *y, double *u) {

  int N = 3;  
  // gp irrelevent and unused

// one gauss point at center

  xi = eta = 1.0L / 3.0L;
  wt = 0.5;

  // Calculate basis function and derivatives at nodel pts
  phi[0]=(1.0-xi-eta);
  phi[1]= xi;
  phi[2]= eta;
  dphidxi[0]=-1.0;
  dphidxi[1]=1.0;
  dphidxi[2]=0.0;
  dphideta[0]=-1.0;
  dphideta[1]=0.0;
  dphideta[2]=1.0;
  
  // Caculate basis function and derivative at GP.

  double dxdxi = 0;
  double dxdeta = 0;
  double dydxi = 0;
  double dydeta = 0;

  for (int i=0; i < N; i++) {
    dxdxi += dphidxi[i] * x[i];
    dxdeta += dphideta[i] * x[i];
    dydxi += dphidxi[i] * y[i];
    dydeta += dphideta[i] * y[i];
  }

  jac = dxdxi * dydeta - dxdeta * dydxi;

  dxidx = dydeta / jac;
  dxidy = -dxdeta / jac;
  detadx = -dydxi / jac;
  detady = dxdxi / jac;

  xx=0.0;
  yy=0.0;
  uu=0.0;
  dudx=0.0;
  dudy=0.0;
  // x[i] is a vector of node coords, x(j, k) 
  for (int i=0; i < 3; i++) {
    xx += x[i] * phi[i];
    yy += y[i] * phi[i];
    if( u ){
      uu += u[i] * phi[i];
      dudx += u[i] * (dphidxi[i]*dxidx+dphideta[i]*detadx);
      dudy += u[i]*(dphidxi[i]*dxidy+dphideta[i]*detady);
    }
  }

  return;
}

// Constructor
BasisLQuad::BasisLQuad() {
  phi = new double[4];
  dphidxi = new double[4];
  dphideta = new double[4];
  abscissa = new double[2];
  weight = new double[2];
  ngp = 4; // number of Gauss points
}

// Destructor
BasisLQuad::~BasisLQuad() {
  delete [] phi;
  delete [] dphidxi;
  delete [] dphideta;
  delete [] abscissa;
  delete [] weight;
}

// Calculates a linear 2D quad basis
void BasisLQuad::getBasis(int gp, double *x, double *y) {
  getBasis(gp, x, y, NULL);
}
void BasisLQuad::getBasis(int gp, double *x, double *y, double *u) {

  abscissa[0] = -1.0/sqrt(3.0);
  abscissa[1] =  1.0/sqrt(3.0);
  weight[0] = 1.0;
  weight[1] = 1.0;

  if(0 == gp){
    xi = abscissa[0];
    eta = abscissa[0];
    wt = weight[0] * weight[0];
  }else if (1 == gp){
    xi = abscissa[1];
    eta = abscissa[0];
    wt = weight[0] * weight[1];
  }else if (2 == gp){
    xi = abscissa[1];
    eta = abscissa[1];
    wt = weight[1] * weight[1];
  }else if (3 == gp){
    xi = abscissa[0];
    eta = abscissa[1];
    wt = weight[0] * weight[1];
  }

  // Calculate basis function and derivatives at nodal pts
  phi[0]=(1.0-xi)*(1.0-eta)/4.0;
  phi[1]=(1.0+xi)*(1.0-eta)/4.0;
  phi[2]=(1.0+xi)*(1.0+eta)/4.0;
  phi[3]=(1.0-xi)*(1.0+eta)/4.0;

  dphidxi[0]=-(1.0-eta)/4.0;
  dphidxi[1]= (1.0-eta)/4.0;
  dphidxi[2]= (1.0+eta)/4.0;
  dphidxi[3]=-(1.0+eta)/4.0;

  dphideta[0]=-(1.0-xi)/4.0;
  dphideta[1]=-(1.0+xi)/4.0;
  dphideta[2]= (1.0+xi)/4.0;
  dphideta[3]= (1.0-xi)/4.0;
  
  // Caculate basis function and derivative at GP.
  double dxdxi  = .25*( (x[1]-x[0])*(1.-eta)+(x[2]-x[3])*(1.+eta) );
  double dxdeta = .25*( (x[3]-x[0])*(1.- xi)+(x[2]-x[1])*(1.+ xi) );
  double dydxi  = .25*( (y[1]-y[0])*(1.-eta)+(y[2]-y[3])*(1.+eta) );
  double dydeta = .25*( (y[3]-y[0])*(1.- xi)+(y[2]-y[1])*(1.+ xi) );

  jac = dxdxi * dydeta - dxdeta * dydxi;

  dxidx = dydeta / jac;
  dxidy = -dxdeta / jac;
  detadx = -dydxi / jac;
  detady = dxdxi / jac;
  // Caculate basis function and derivative at GP.
  xx=0.0;
  yy=0.0;
  uu=0.0;
  dudx=0.0;
  dudy=0.0;
  // x[i] is a vector of node coords, x(j, k) 
  for (int i=0; i < 4; i++) {
    xx += x[i] * phi[i];
    yy += y[i] * phi[i];
    if( u ){
      uu += u[i] * phi[i];
      dudx += u[i] * (dphidxi[i]*dxidx+dphideta[i]*detadx);
      dudy += u[i]*(dphidxi[i]*dxidy+dphideta[i]*detady);
    }
  }

  return;
}

//Constructor
BasisQTri::BasisQTri() {
  phi = new double[6];
  dphidxi = new double[6];
  dphideta = new double[6];
  ngp = 3;
}

//Destructor
BasisQTri::~BasisQTri() {
  delete [] phi;
  delete [] dphidxi;
  delete [] dphideta;
}

//Calculates a linear 1D basis
void BasisQTri::getBasis(int gp, double *x, double *y) {}
void BasisQTri::getBasis(int gp, double *x, double *y, double *u) {
  int N = 6;
  wt = 1.0L / 6.0L;
  if (gp==0) {xi = 2.0L/3.0L; eta=1.0L/6.0L;}
  if (gp==1) {xi = 1.0L/6.0L; eta=2.0L/3.0L;}
  if (gp==2) {xi = 1.0L/6.0L; eta=1.0L/6.0L;}

  // Calculate basis function and derivatives at nodel pts
  phi[0]=2.0 * (1.0 - xi - eta) * (0.5 - xi - eta);
  phi[1]= 2.0 * xi * (xi - 0.5);
  phi[2]= 2.0 * eta * (eta - 0.5);
  phi[3]=4.0 * (1.0 - xi - eta) * xi;
  phi[4]= 4.0 * xi * eta;
  phi[5]= 4.0 * (1.0 - xi - eta) * eta;
  dphidxi[0]=-2.0 * (0.5 - xi - eta) - 2.0 * (1.0 - xi - eta);
  dphidxi[1]= 2.0 * (xi - 0.5) + 2.0 * xi;
  dphidxi[2]= 0.0;
  dphidxi[3]=-4.0 * xi + 4.0 * (1.0 - xi - eta);
  dphidxi[4]= 4.0 * eta;
  dphidxi[5]= -4.0 * eta;
  dphideta[0]=-2.0 * (0.5 - xi - eta) - 2.0 * (1.0 - xi - eta);
  dphideta[1]= 0.0;
  dphideta[2]= 2.0 * eta + 2.0 * (eta - 0.5);
  dphideta[3]=-4.0 * xi;
  dphideta[4]= 4.0 * xi;
  dphideta[5]= 4.0 * (1.0 - xi - eta) - 4.0 * eta;
  
  // Caculate basis function and derivative at GP.
  xx=0.0;
  yy=0.0;
  uu=0.0;
  dudx=0.0;
  for (int i=0; i < N; i++) {
    xx += wt * x[i] * phi[i];
    yy += wt * y[i] * phi[i];
    uu += wt * u[i] * phi[i];
    dudx += wt * u[i] * dphideta[i];
  }

  return;
}
